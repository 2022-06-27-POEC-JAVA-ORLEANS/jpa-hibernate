package com.example.demo.converter;

import com.example.demo.domain.Certification;
import com.example.demo.domain.Movie;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;
import java.util.stream.Stream;

// Quand tu as créé cette classe
// l'ajouter au niveau de l'entity manager dans nos config (faire de même dans la partie config des tests)

@Converter(autoApply = true)
public class CertificationAttributeConverter implements AttributeConverter<Certification, Integer> {


    @Override
    public Integer convertToDatabaseColumn(Certification attribute) {
        // Cette première méthode propose de convertir une certification vers l'integer
        // on va aller vers la bdd
        //
        return attribute != null ? attribute.getKey() : null;
    }

    @Override
    public Certification convertToEntityAttribute(Integer integer) {
        // ici on va récupérer de la bdd un integer
        // et on va le transformer en Certification
        return Stream.of(Certification.values()).filter(certif -> certif.getKey().equals(integer)).findFirst().orElse(null);
    }
}
