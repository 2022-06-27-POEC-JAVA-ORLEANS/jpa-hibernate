package com.example.demo.domain;

import javax.persistence.*;

@Entity
//@Table(name = "toto") Pour changer le nom de la table
public class Movie {

    // A mettre ici avant de créer une classe à part
    //public enum Certification {
        //TOUS_PUBLIC, INTERDIT_MOINS_12, INTERDIS_MOINS_16, INTERDIS_MOINS_18
    //}

    @Id
    // la facon dont l'id est généré
    // sequence utilise une sequence en bdd
    // hors de la table Movie dans dbeaver  on a la table sequences
    // on voit que par défaut ça s'incrémente de 1
    // on voit la valeur actuelle de la séquence
    // pour avoir la séquence actuelle :
    // select nextval("hibernate-sequence"); -> taper ça dans le script
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    // différent type:
    // idendity : similaire à la sequence, associé à la table et pas décoléré de la table pas supporté par toutes les tables
    // table : très peu utilisé : hibernate créé une table pour la génération de l'id
    // auto : on laisse hibenate décider quelle est la meilleure stratégie
    private Long id;

    // Si on avait fait le mapping explicitement
    //@Column(name="name")
    // contraintes
    @Column(nullable=false, unique = true)
    private String name;

    @Column(name="description")
    // @Transient -> pour décider qu'un attribut ne devrait pas être mapp&
    private String description;

    //@Enumerated inserera yun chiffre en bdd
    //@Enumerated(EnumType.STRING) // pour insérer un string à la place d'un chiffre
    // plus besoin une fois les converters mis en place
    private Certification certification;

    public Certification getCertification() {
        return certification;
    }

    public void setCertification(Certification certification) {
        this.certification = certification;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
