insert into Movie (name, id, certification) values ('Training Day', -1L, 2);
insert into Movie (name, id, certification) values ('Boyz in the hood', -2L, 3);