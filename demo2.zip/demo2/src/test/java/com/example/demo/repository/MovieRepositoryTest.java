package com.example.demo.repository;

import com.example.demo.config.PersistenceConfigTest;
import com.example.demo.domain.Certification;
import com.example.demo.domain.Movie;
import org.hibernate.LazyInitializationException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.jdbc.SqlConfig;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat; // Import static de junit
import static org.junit.jupiter.api.Assertions.assertThrows;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = {PersistenceConfigTest.class})
@SqlConfig(dataSource = "dataSourceH2", transactionManager = "transactionManager")
@Sql({"/datas/data-test.sql"})
public class MovieRepositoryTest {



    @Autowired
    private MovieRepository repository;

    private static final Logger LOGGER = LoggerFactory.getLogger(MovieRepository.class);


    @Test
    public void save_casNominal() {

        Movie movie = new Movie();
        movie.setName("Training Day");
        repository.persist(movie);
        System.out.println("fin de test");
    }

    @Test
    public void find_casNominal() {

        Movie movie = repository.find(-2L);
        assertThat(movie.getName()).as("mauvais film récupéré").isEqualTo("Boyz in the hood");
    }

    @Test
    public void getAll_casNominal() {

        List<Movie> movies = repository.getAll();
        assertThat(movies).as("l'ensemble des films n'a pas été récupéré").hasSize(2);
    }

    @Test
    public void merge_casSimule() {
        Movie movie = new Movie();
        movie.setName("Training Day 2");
        movie.setId(-1L);
        Movie movieMerged = repository.merge(movie);
        assertThat(movieMerged.getName()).as("le nom du film est incorrect").isEqualTo("Training Day 2");
    }


    @Test
    public void remove_casNominal() {
        repository.remove(-2L);

        List<Movie> movies = repository.getAll();
        assertThat(movies).as("le film n'a pas été supprimé").hasSize(1);
    }

    @Test
    public void getReference_casNominal() {
        Movie movie = repository.getReference(-2L);
        assertThat(movie.getId()).as("La référence n'a pas été correctement chargée").isEqualTo(-2);
    }

    @Test
    public void getReference2_casNominal() {
        assertThrows(LazyInitializationException.class, () -> {
            Movie movie = repository.getReference2(-2L);
            LOGGER.trace("moviee name : " + movie.getName());
            assertThat(movie.getId()).as("La référence n'a pas été correctement chargée").isEqualTo(-2);
        }, "Nous n'avons pas eu la bonne exception LazyInitializationException");
    }

    @Test
    public void save2_casNominal() {

        Movie movie = new Movie();
        movie.setName("Mon film de ouf");
        movie.setCertification(Certification.INTERDIS_MOINS_16);
        repository.persist(movie);

        System.out.println("fin de test");
    }

    @Test
    public void find2_casNominal() {

        Movie movie = repository.find(-2L);
        assertThat(movie.getName()).as("mauvais film récupéré").isEqualTo("Boyz in the hood");
        assertThat(movie.getCertification()).as("Le converter n'a pas fonctionné").isEqualTo(Certification.INTERDIS_MOINS_16);
    }


}
