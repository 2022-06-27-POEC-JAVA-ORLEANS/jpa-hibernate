package com.example.demo.repository;

import com.example.demo.domain.Movie;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;
import java.util.List;

// @Repository
public class MovieRepository2 {

    private static final Logger LOGGER = LoggerFactory.getLogger(MovieRepository2.class);

    @PersistenceContext
    EntityManager entityManager;

    @Transactional
    public void persist(Movie movie) {
        LOGGER.trace(" entityManager.contains() : " + entityManager.contains(movie)); // on regarde si notre entité movie est en cession ou pas avant persistance : false
        entityManager.persist(movie);
        entityManager.detach(movie); // pour détacher l'entité de la session
        LOGGER.trace(" entityManager.contains() : " + entityManager.contains(movie)); // on regarde si notre entité movie est en cession ou pas après persistance : false

    }

    @Transactional
    public void persist2(Movie movie) {
        entityManager.persist(movie);
        entityManager.flush();
    }

    public Movie find(Long id) {
        Movie movie = entityManager.find(Movie.class, id);
        return movie;
    }

    public List<Movie> getAll() {
        return entityManager.createQuery("from Movie", Movie.class).getResultList(); // select * en JPQL (récupérer plusieurs entités)
    }

    @Transactional
    public Movie merge(Movie movie) {
        // on a récupéré un objet donc on sera dans l'état managed
        return entityManager.merge(movie);
    }

    @Transactional // comme ya de l'écriture on met l'annotation
    public void remove(Long id) {
        Movie movie = entityManager.find(Movie.class, id);
        entityManager.remove(movie);

    }

    @Transactional // A rajouter pour faire la démo avec le LOGGER pour montrer que sur demande on peut récupérer les données via le proxy
    public Movie getReference(Long l) {
        Movie result = entityManager.getReference(Movie.class,l);
        LOGGER.trace("movie Name : " + result.getName());
        return result;
    }

    // Montrer qu'ici on a plus de session on est en mode detached
    // du coup on peut par récupérer les données du proxy
    // on va avoir une lazyException
    public Movie getReference2(Long l) {
        return entityManager.getReference(Movie.class,l);
    }
}
