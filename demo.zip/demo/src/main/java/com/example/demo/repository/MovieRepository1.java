package com.example.demo.repository;

import com.example.demo.domain.Movie;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;
import java.util.List;

// @Repository // Permettra d'accèder à la base de donnée
public class MovieRepository1 {

    private static final Logger LOGGER = LoggerFactory.getLogger(MovieRepository1.class);

    @PersistenceContext // permet de gérer les entittés qui contiennent des données qui seront persistées, et le contexte permet de gérer les différents états que nos entités peuvent avoir (Detached, Managed)
    EntityManager entityManager;

    // L'API EntityManager est utilisée pour créer et supprimer des instances de persistence de données, pour trouver des entités avec leur clef primaire,
    // ou faire des requêtes à travers les entités

    @Transactional
    public void persist(Movie movie) {
        //throw new UnsupportedOperationException();
        // On va utiliser la méthode contains pour savoir si note entité est en session ou pas
        // Ici elle n'est pas en session
        LOGGER.trace(" entityManager.contains() : " + entityManager.contains(movie));
        entityManager.persist(movie);
        // Après avoir été persistée elle est en session :)
        LOGGER.trace(" entityManager.contains() : " + entityManager.contains(movie));

    }

    // Pour cette méthode
    // pas de transaction
    // une session ouverte et fermée pour le contexte
    // mais l'entité n'est pas en session
    // pas de transaction car pas d'écriture en bdd
    public Movie find(Long id) {
        Movie movie = entityManager.find(Movie.class, id);
        LOGGER.trace(" entityManager.contains() : " + entityManager.contains(movie));
        return movie;
    }

    public List<Movie> getAll() {
        // throw new UnsupportedOperationException();
        return entityManager.createQuery("from Movie", Movie.class).getResultList(); // select * en JPQL (récupérer plusieurs entités)
    }

}
