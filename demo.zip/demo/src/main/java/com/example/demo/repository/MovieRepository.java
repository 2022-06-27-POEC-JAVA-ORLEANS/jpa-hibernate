package com.example.demo.repository;

import com.example.demo.domain.Movie;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;

@Repository
public class MovieRepository {

    private static final Logger LOGGER = LoggerFactory.getLogger(MovieRepository.class);

    @PersistenceContext
    EntityManager entityManager;

    @Transactional
    public void persist(Movie movie) {
        //LOGGER.trace(" entityManager.contains() : " + entityManager.contains(movie));
        entityManager.persist(movie);
        //entityManager.detach(movie);
        //LOGGER.trace(" entityManager.contains() : " + entityManager.contains(movie));

    }

    @Transactional
    public void persist2(Movie movie) {
        entityManager.persist(movie);
        entityManager.flush();
    }

    public Movie find(Long id) {
        Movie movie = entityManager.find(Movie.class, id);
        return movie;
    }

    public List<Movie> getAll() {
        return entityManager.createQuery("from Movie", Movie.class).getResultList();
    }

    @Transactional
    public Movie merge(Movie movie) {
        return entityManager.merge(movie);
    }

    @Transactional
    public void remove(Long id) {
        // On va passer d'un état managed
        // à l'état removed
        Movie movie = entityManager.find(Movie.class, id);
        entityManager.remove(movie);

    }

    @Transactional
    public Movie getReference(Long l) {
        Movie result = entityManager.getReference(Movie.class,l);
        LOGGER.trace("movie Name : " + result.getName());
        return result;
    }


    public Movie getReference2(Long l) {
        return entityManager.getReference(Movie.class,l);
    }

    @Transactional
    public void remove2(Long id) {
        // faudra appeler cette nouvelle méthode dans nos test unitaires ;)
        Movie movie = entityManager.find(Movie.class, id); // montrer qu'ici j'ai un select d'effectué
        Movie movie2 = entityManager.find(Movie.class, id); // et qu'à partir d'ici il récupère la même valeur dans son cache
        Movie movie3 = entityManager.find(Movie.class, id);
        entityManager.remove(movie);

    }

    @Transactional
    public Movie merge2(Movie movie) {
        Movie myMovie = entityManager.find(Movie.class, movie.getId()); // montrer qu'ici je fais le taff du merge en amont, je récupère déjà l'entité en base
        return entityManager.merge(movie); // du coup au niveau du merge, il ne va pas refaire de select mais récupérée l'info dans le cache :)
    }

    @Transactional
    public Movie merge3(Movie movie) {
        entityManager.merge(movie);
        // Quand on va rentrer dans le merge il va faire son select
        // pour avoir l'état en bdd
        // mais l'update du nom ne se fera qu'au sortir de la méthode (au moment du flush)
        // pourtant myMovie sera à jour
        // car hibernate nous renvoit toujours l'entité à jour
        // dans myMovie on a le nouveau nom
        // pourtant l'insert en bdd n'a pas encoré eté fait
        // il décide donc quand il met à jour la bdd
        // mais les entités renvoyées sont toujours à jour
        Movie myMovie = entityManager.find(Movie.class, movie.getId());
        return myMovie;
    }

    @Transactional
    public Optional<Movie> update(Movie movie) {

        if(movie.getId() == null) {
            return Optional.empty();
        }

        Movie updMovie = entityManager.find(Movie.class, movie.getId());

        if(updMovie != null) {
            // dirty checking
            updMovie.setName(movie.getName());
            updMovie.setDescription(movie.getDescription());
        }

        return Optional.ofNullable(updMovie);
    }

    @Transactional
    public boolean remove3(Long l) {

        boolean result = false;

        if (l != null) {

            Movie movie = entityManager.find(Movie.class, l);

            if (movie != null) {
                entityManager.remove(movie);
                result = true;
            }

        }

        return result;

    }
}
