package com.example.demo.repository;

import com.example.demo.config.PersistenceConfigTest;
import com.example.demo.domain.Movie;
import org.hibernate.LazyInitializationException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.jdbc.SqlConfig;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat; // Import static de junit
import static org.junit.jupiter.api.Assertions.assertThrows;

@ExtendWith(SpringExtension.class)//permet de s'éxecuter dans un context spring
@ContextConfiguration(classes = {PersistenceConfigTest.class}) // les classes de configuration dont à besoin spring pour s'initialiser
@SqlConfig(dataSource = "dataSourceH2", transactionManager = "transactionManager") // permet a spring d'insérer les données via la data source et à transaction manager qu'on a configuré (on retrouve ça dans notre fihcier de config PersistenceConfig
@Sql({"/datas/data-test.sql"}) // // le fichier qui va inséré les données en base
public class MovieRepositoryTest {


    // Création d'un premier test unitaire pour vérifier la config

    @Autowired // Injection de dépenance
    private MovieRepository repository;

    // Mettre ce logger quand on parle de LazyException
    private static final Logger LOGGER = LoggerFactory.getLogger(MovieRepository.class);


    @Test
    public void save_casNominal() {

        Movie movie = new Movie(); // état TRANSIENT
        movie.setName("Training Day"); // A ce stade on a créé un movie mais on ne l'a pas encore donné au contexte de persistance
        repository.persist(movie); // Aller dans l'implémentation du persist et ajouter un EntityManager et @Transactional

        System.out.println("fin de test"); // A mettre quand on explique les différents états JPA
    }

    @Test
    public void find_casNominal() {

        Movie movie = repository.find(-2L);
        assertThat(movie.getName()).as("mauvais film récupéré").isEqualTo("Boyz in the hood");
        // On est passé de la BDD à l'état Managed !
    }

    @Test
    public void getAll_casNominal() {

        List<Movie> movies = repository.getAll();
        // Vérifier que ma liste contient deux résultats
        assertThat(movies).as("l'ensemble des films n'a pas été récupéré").hasSize(2);
    }

    @Test
    public void merge_casSimule() {
        Movie movie = new Movie();
        movie.setName("Training Day 2");
        movie.setId(-1L); // on le set mais dans la vraie vie on le ferait as on simule la mise à jour la
        Movie movieMerged = repository.merge(movie);
        assertThat(movieMerged.getName()).as("le nom du film est incorrect").isEqualTo("Training Day 2");
    }


    @Test
    public void remove_casNominal() {
        repository.remove(-2L);

        List<Movie> movies = repository.getAll();
        assertThat(movies).as("le film n'a pas été supprimé").hasSize(1);
    }

    @Test
    public void getReference_casNominal() {
        Movie movie = repository.getReference(-2L);
        assertThat(movie.getId()).as("La référence n'a pas été correctement chargée").isEqualTo(-2);
    }

    @Test
    public void getReference2_casNominal() {

        // Voila pourquoi il est toujours essentiel de savoir si on est dans un session ou non 

        assertThrows(LazyInitializationException.class, () -> {
            Movie movie = repository.getReference2(-2L);
            LOGGER.trace("moviee name : " + movie.getName());
            assertThat(movie.getId()).as("La référence n'a pas été correctement chargée").isEqualTo(-2);
        }, "Nous n'avons pas eu la bonne exception LazyInitializationException");
    }

}
