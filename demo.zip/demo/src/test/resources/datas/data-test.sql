insert into Movie (name, id) values ('Training Day', -1L);
insert into Movie (name, id) values ('Boyz in the hood', -2L);