insert into Movie (name, id, certification) values ('Training Day', -1L, 3L)
insert into Movie (name, id, certification) values ('Boyz in the hood', -2L, 2L)