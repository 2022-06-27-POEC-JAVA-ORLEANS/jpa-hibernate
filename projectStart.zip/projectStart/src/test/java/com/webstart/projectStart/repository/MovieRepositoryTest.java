package com.webstart.projectStart.repository;

import com.webstart.projectStart.config.PersistenceConfigTest;
import com.webstart.projectStart.entity.Certification;
import com.webstart.projectStart.entity.Movie;
import org.hibernate.LazyInitializationException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.jdbc.SqlConfig;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;

@ExtendWith(SpringExtension.class) // permet d'exécuter la classe test dans le context Spring
@ContextConfiguration(classes = {PersistenceConfigTest.class})
@SqlConfig(dataSource = "dataSourceH2", transactionManager = "transactionManager")
// permet à spring d'insérer les données via la data source et transaction manager qu'on a configuré dans PersistenceConfig
@Sql({"/data/data-test.sql"}) // le fichier qui va insérer les données en base
public class MovieRepositoryTest {

    @Autowired // la classe MovieRepository est injectée grâce à Spring
    private MovieRepository repository;

    @Test
    public void save_casNominal() {
        Movie movie = new Movie();
        movie.setName("Banshee");
        repository.persist(movie); // A ce stade j'ai eu une erreur une exception UnsupportedOperationException car la méthode persit n'as pas encore été donné au contexte de persistence dans MovieRepository
        System.out.println("Fin de test");
    }

    @Test
    public void find_casNominal() {

        // s'assurer que si je passe l'id -1, je récupère bien le film Training Day
        Movie movie = repository.find(-1L);
        assertThat(movie.getName()).as("mauvais film récupéré").isEqualTo("Training Day");
    }

    @Test
    public void getAll_casNominal() {
        // S'assurer que quand je récupère toutes les données de la BDD j'ai bien 2 films
        List<Movie> movies = repository.getAll();
        assertThat(movies).as("La liste ne contient pas 2 films").hasSize(2);
    }

    @Test
    public void merge_casNominal() {
        // faudra modifier le titre boyz in the hood en 'boyz in tha hood'
        // s'assurer que le titre récupérer après update est bien 'boyz in tha hood'
        Movie movie = new Movie();
        movie.setName("boyz in tha hood");
        movie.setId(-2L);
        Movie movieUpdated = repository.merge(movie);
        assertThat(movieUpdated.getName()).as("le nom du film est incorrect").isEqualTo("boyz in tha hood");

    }

    @Test
    public void remove_casNominal() {
        // Supprimer le film avec l'id 1
        // et s'assurer qu'en BDD je n'ai qu'un film

        repository.remove(-2L);
        List<Movie> movies = repository.getAll();
        assertThat(movies).as("La liste ne contient pas 1 films").hasSize(1);

    }

    @Test
    public void getReference_casNominal() {
        // s'assurer que si je passe l'id -2
        // l'id de l'entité Movie récupérée est bien -2
        Movie movie = repository.getReference(-2L);
        assertThat(movie.getName()).as("Le titre du film n'est pas bon !").isEqualTo("Boyz in the hood");
    }

    // LazyInitiationException

    // Avec les proxy on parle de chargement à la demande, c’est à dire que c’est une fois qu’on accède à des données non
    // chargées qu’hibernate va se charger de les recuperer  en bdd a une condition qu’on soit dans un état managed.
    //Illustron cette condition.

    @Test
    public void getReference_fail() {

        assertThrows(LazyInitializationException.class, () -> {
            Movie movie = repository.getReferenceFail(-2L);
            assertThat(movie.getName()).as("Le titre du film n'est pas bon !").isEqualTo("Boyz in the hood");
        }, "Nous n'avons pas reçu la bonne exception LazyInitializationException");
    }

    // Le flush

    @Test
    public void save_casNominal2() {
        Movie movie = new Movie();
        movie.setName("Banshee");
        repository.persist2(movie);
    }

    // Le dirty checking

    // créer un service dans un package service côté test avec l'annotation @Service (MovieService)
    // avec une méthode updateDescription qui permettra de mettre à jour la description d'un film
    // injecter une dépendance vers le repository avec l'annotation @Autowired
    // dans l'entité Movie ajouter un atribut avec getters et setters description
    // créer une nouvelle classe test MovieServiceTest qui appelera la méthode updateDescription de votre service
    // vous appelerez la méthode upadateDescription de votre service en lui passant un identifiant (-2L) et une nouvelle description pour votre film
    // le service devra appelet le repository et mettre à jour la nouvelle desription pour l'entité en BDD liée à l'id -2L

    // Sauf que cette fois-ci
    // dans la méthode updateDescription
    // vous récuperez l'entité en BDD avec la méthode find
    // une fois l'entité récupéré vous modifierez seulement la valeur de l'attribut description de l'entité récupérée en BDD
    // côté test, vérifiez que votre entité à été mise à jour
    // comment, soit en observant les logs, soit en faisant un assert

    // on appel null part la méthode merge, on fait juste un setDescription




    // Le cache de premier niveau

    @Test
    public void remove2_casNominal() {

        repository.remove2(-2L);
        List<Movie> movies = repository.getAll();
        assertThat(movies).as("La liste ne contient pas 1 films").hasSize(1);

    }
    // Le cache de premier niveau
    @Test
    public void merge2_casNominal() {

        Movie movie = new Movie();
        movie.setName("boyz in tha hood");
        movie.setId(-2L);
        Movie movieUpdated = repository.merge2(movie);
        assertThat(movieUpdated.getName()).as("le nom du film est incorrect").isEqualTo("boyz in tha hood");

    }


    // Les énumérations et converters
    @Test
    public void save2_casNominal2() {
        Movie movie = new Movie();
        movie.setName("Banshee");
        //movie.setCertification(Movie.Certification.INTERDITS_AU_MOINS_12);
        // vérifier qu'en BDD ça m'a rentré un integer
        movie.setCertification(Certification.INTERDITS_AU_MOINS_12);
        repository.persist2(movie);
    }

    // Créer une méthode de récupération
    // vous aller vérifier si quand on récupère un film c'est une string qui s'affiche à la place de l'integer
    // pour ça modifier le jeu de données dans data-test.sql et ajouter une valeur pour la colonne certification

    @Test
    public void find2_casNominal() {

        // s'assurer que si je passe l'id -1, je récupère bien le film Training Day
        Movie movie = repository.find(-1L);
        assertThat(movie.getName()).as("mauvais film récupéré").isEqualTo("Training Day");
        assertThat(movie.getCertification()).as("Le converter n'a pas fonctionné").isEqualTo(Certification.INTERDITS_AU_MOINS_18);
    }

    // TP

}
