package com.webstart.projectStart.repository;

import com.webstart.projectStart.entity.Movie;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;

@Repository
public class MovieRepository {

    private static final Logger LOGGER = LoggerFactory.getLogger(MovieRepository.class);

    @PersistenceContext // permet de gérer les entittés qui contiennent des données qui seront persistées, et le contexte permet de gérer les différents états que nos entités peuvent avoir (Detached, Managed)
    EntityManager entityManager;


    // L'API EntityManager est utilisée pour créer et supprimer des instances de persistence de données, pour trouver des entités avec leur clef primaire,
    // ou faire des requêtes à travers les entités
    @Transactional
    public void persist(Movie movie) {
        // throw new UnsupportedOperationException();
        // LOGGER.trace("entityManager.contains(movie) : " + entityManager.contains(movie));
        entityManager.persist(movie); // permet d'insérer mon objet en BDD
        // LOGGER.trace("entityManager.contains(movie) : " + entityManager.contains(movie));

    }

    @Transactional
    public void persist2(Movie movie) {

        entityManager.persist(movie);
        entityManager.flush();// force le flush, l'insertion des données en bdd
        // pas une bonne pratique
        // puisque derrière hibernante re-flush

    }


    // Pour cette méthode
    // pas de transaction
    // une session ouverte et fermée pour le contexte
    // mais l'entité n'est pas en session
    // pas de transaction car pas d'écriture en bdd
    public Movie find(Long id) {
        Movie movie = entityManager.find(Movie.class, id);
        LOGGER.trace("entityManager.contains(movie) : " + entityManager.contains(movie));
        return movie;
    }

    public List<Movie> getAll() {
        List<Movie> movies = entityManager.createQuery("from Movie", Movie.class).getResultList(); // SELECT * EN JPQL
        // DE RÉCUPERER PLUSIEURS ENTITÉS
        return movies;
    }

    @Transactional
    public Movie merge(Movie movie) {
        Movie movieMerged = entityManager.merge(movie);
        return movieMerged;
    }

    @Transactional
    public void remove(Long id) {
        // On passe de l'état Managed
        // à l'état removed !
        Movie movie = entityManager.find(Movie.class, id);
        entityManager.remove(movie);
    }

    @Transactional
    public Movie getReference(Long id) {
        // On passe de l'état Managed
        // à l'état removed !
        Movie movie = entityManager.getReference(Movie.class, id);
        LOGGER.trace("movie.getName() " + movie.getName());
        return movie;
    }

    public Movie getReferenceFail(Long id) {
        Movie movie = entityManager.getReference(Movie.class, id);
        return movie;
    }

    @Transactional
    public Optional<Movie> update(Movie movie) {

        // Si quand je veux modifier mon entité j'ai rien
        // je renvoie du vide
        if(movie.getId() == null) {
            return Optional.empty();
        }

        // je cherche la correspondance si j'ai un id
        Movie movieInBDD = entityManager.find(Movie.class, movie.getId());

        // Si j'ai une entité en bdd je la mets à jour
        if(movieInBDD != null) {
            // dirty checking
            movieInBDD.setName(movie.getName());
            movieInBDD.setDescription(movie.getDescription());
        }

        // Si j'ai quelque chose en bdd je retourne l'entité MAJ
        // Sinon je renvoie rien
        return Optional.ofNullable(movieInBDD);

    }

    @Transactional
    public boolean delete(Long id) {

        boolean isDeleted = false;

        if(id != null) {

            Movie movie = entityManager.find(Movie.class, id);

            if(movie != null) {
                entityManager.remove(movie);
                isDeleted = true;
            }

        }

        return isDeleted;
    }

    // Explication sur le cache de bas niveau
    @Transactional
    public void remove2(Long id) {
        // on va appeler cette méthode depuis nos tests pour montrer qu'un seul select a été réalisé et pas 3
        // les deux autres movie ont été récupéré depuis le cache d'hibernate
        Movie movie = entityManager.find(Movie.class, id);
        Movie movie2 = entityManager.find(Movie.class, id);
        Movie movie3 = entityManager.find(Movie.class, id);

        entityManager.remove(movie);
    }

    // Explication sur le cache de bas niveau
    @Transactional
    public Movie merge2(Movie movieAvecNouvelleDonnéesAMettreAjour) {
        // que se passe-til si je fais le travail du merge en amont?
        // je vais fait un select de l'entité avant de faire un merge?
        // le merge va-til refaire le select pour séléctionner l'entité à updater?
        Movie movieRecupereDepuisLaBDD = entityManager.find(Movie.class, movieAvecNouvelleDonnéesAMettreAjour.getId());
        Movie movieMerged = entityManager.merge(movieAvecNouvelleDonnéesAMettreAjour);
        return movieMerged;
    }

}
