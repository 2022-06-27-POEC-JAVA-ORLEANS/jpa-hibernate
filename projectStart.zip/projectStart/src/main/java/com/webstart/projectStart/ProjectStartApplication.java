package com.webstart.projectStart;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectStartApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjectStartApplication.class, args);
	}

}
