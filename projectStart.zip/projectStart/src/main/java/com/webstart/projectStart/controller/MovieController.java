package com.webstart.projectStart.controller;

import com.webstart.projectStart.entity.Movie;
import com.webstart.projectStart.repository.MovieRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

// indique à spring qu'on a un controller REST
@RestController
@RequestMapping("/movie")
public class MovieController {

    @Autowired // Injection de dépendance
    MovieRepository repository;

    // Gérer l'instertion d'un film en BDD

    @PostMapping("/")
    public Movie create(@RequestBody Movie movie) {
        repository.persist(movie);
        return movie;
    }


    // Récupérer un movie par son ID

    @GetMapping("/{id}")
    public Movie get(@PathVariable("id") Long id) {
        return repository.find(id);
    }


    // Récupérer tous les movies

    @GetMapping("/")
    public List<Movie> getAll() {
        return repository.getAll();
    }


    // En modifier un
    //@PutMapping("/") --> V1
    //public Movie update(@RequestBody Movie movie) {
    //return repository.merge(movie);
    //}

    @PutMapping("/")
    public ResponseEntity<Movie> update(@RequestBody Movie movie) {

        Optional<Movie> result = repository.update(movie);
        // si pas de correspondance
        // je renvoie une erreur 404
        if(result.isEmpty()) {
            return ResponseEntity.notFound().build();
        } else {
            // si code 200 avec l'entité
            return ResponseEntity.ok(result.get());
        }

    }



    // En supprimer un
    @DeleteMapping("/{id}")
    public ResponseEntity<Movie> delete(@PathVariable("id") Long id) {

        boolean isDeleted = repository.delete(id);
        return isDeleted ? ResponseEntity.ok().build() : ResponseEntity.notFound().build();

    }



    // Le cache de premier niveau

}
