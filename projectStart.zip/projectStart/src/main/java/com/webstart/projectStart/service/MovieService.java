package com.webstart.projectStart.service;

import com.webstart.projectStart.entity.Movie;
import com.webstart.projectStart.repository.MovieRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;

@Service
public class MovieService {

    @Autowired
    MovieRepository repository;

    @Transactional
    public void updateDescription(Long id, String description) {
        // dirty checking
        Movie movie = repository.find(id);
        movie.setDescription(description);
    }

}
