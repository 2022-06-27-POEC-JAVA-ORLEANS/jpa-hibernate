package com.webstart.projectStart.converter;

import com.webstart.projectStart.entity.Certification;

import javax.persistence.AttributeConverter;
import java.util.stream.Stream;

// Quand tu as créé cette classe
// l'ajouter au niveau de l'entity manager dans nos config (faire de même dans la partie config des tests)
public class CertificationAttributeConverter implements AttributeConverter<Certification, Integer> {

    @Override
    public Integer convertToDatabaseColumn(Certification certification) {
        // Cette première méthode propose de convertir une certification vers l'integer
        return certification != null ? certification.getKey() : null;
    }

    @Override
    public Certification convertToEntityAttribute(Integer integer) {
        // Cette deuxième méthode propose de convertir un integer vers une Certification

        // on va créer un stream de donnée
        //a vec les valeurs de nos enums
        // et récupérer dans ce stream la certification dont l'id
        // et égale à celui récupéré en BDD
        return Stream.of(Certification.values()).filter(certif -> certif.getKey().equals(integer)).findFirst().orElse(null);
    }

}
