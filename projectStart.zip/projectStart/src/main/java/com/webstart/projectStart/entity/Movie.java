package com.webstart.projectStart.entity;

import javax.persistence.*;

@Entity
// @Table(name="toto") // la table en bdd s'appelera toto
public class Movie {

    //public enum Certification {
        //TOUS_PUBLIC, INTERDITS_AU_MOINS_12, INTERDITS_AU_MOINS_16, INTERDITS_AU_MOINS_18
    // }

    // Mapping en Field Access
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    // différents types :
    // identity : similaire à sequence, sauf que la sequence n'est pas isolé de la table, c'est pas supporté par toutes les technos
    // table : génère une table pour la générationd des id (peu utilisé)
    // Auto : on laisse hibernate choisir le bon type
    private Long id;

    // @Column(name = "name") -> mapping explicit
    @Column(nullable = false, unique = true)
    private String name;

    // @Transient // l'attribut ne doit pas être mappé (on doit pas générer de column pour cet attribut
    private String description;

    //@Enumerated
    //@Enumerated(EnumType.STRING)
    public Certification certification;

    public Certification getCertification() {
        return certification;
    }

    public void setCertification(Certification certification) {
        this.certification = certification;
    }

    // Si onavait annoté les getters on serait en Mapping en property Access

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
